package animal;

public class Hippo extends Animal {
		
	@Override
	public void makeNoise() {
		// TODO Auto-generated method stub
		System.out.println("This is veri big mounth");
	}
	
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("veg only");
	}

	@Override
	public void roam() {
		// TODO Auto-generated method stub
		
		
	}
	
}
