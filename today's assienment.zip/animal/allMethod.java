package animal;

public interface allMethod {
	
	void makeNoise();
	void eat();
	void roam();
}
